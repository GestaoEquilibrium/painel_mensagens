# Assistente Equilibrium — extensão para WhatsApp Web

Painel lateral que aparece dentro do **WhatsApp Web**. Quando uma mensagem do
paciente chega, ele **lê o texto, identifica a intenção e mostra as categorias e
mensagens sugeridas** do painel (os mesmos cards do Supabase, ao vivo).

> **Importante:** a extensão **só sugere**. Ela não responde sozinha, não envia
> nada e não automatiza o WhatsApp. Quem lê e envia é sempre a atendente —
> exatamente do jeito manual que a clínica prefere.

---

## Como instalar (Chrome ou Edge)

1. Baixe e **descompacte** esta pasta em um lugar fixo do computador
   (ex.: `C:\Equilibrium\extensao\`). Não apague depois — o navegador lê os
   arquivos desse local.
2. Abra o navegador e vá em:
   - Chrome: `chrome://extensions`
   - Edge: `edge://extensions`
3. Ative o **Modo do desenvolvedor** (canto superior direito).
4. Clique em **Carregar sem compactação** (Load unpacked) e selecione a pasta
   `equilibrium-whatsapp`.
5. Pronto. Abra `https://web.whatsapp.com` e o painel aparece no canto direito.

Para repetir nos outros computadores da recepção, é só copiar a pasta e refazer
os passos 2 a 4.

---

## Como usar

- Abra uma conversa no WhatsApp Web. Quando chegar uma mensagem, o painel já
  mostra as sugestões ranqueadas (a melhor primeiro), com o **código** do card,
  o **nível de correspondência** e o texto pronto.
- Clique em **Copiar mensagem**, cole no WhatsApp, ajuste o que precisar e envie.
- Se a detecção automática falhar (ver abaixo), cole a mensagem no campo
  **“ou cole/escreva uma mensagem para analisar”** e clique em **Analisar**.
- O botão **↻** recarrega os cards do painel (use depois de criar/editar cards).
- O **×** recolhe o painel; o botão redondo **E** no canto reabre.

---

## Avisos honestos

- **O HTML do WhatsApp Web muda de tempos em tempos.** Se um dia o painel parar
  de detectar a mensagem sozinho, o campo manual de “Analisar” continua
  funcionando, e é só me avisar para atualizar o seletor de leitura.
- A extensão usa a **chave anônima** do Supabase (a mesma que já está no painel
  publicado, que é pública por natureza). Ela só lê os cards.
- Não instala nada além do painel; não acessa outras abas nem outros sites
  além de `web.whatsapp.com` e do Supabase do projeto.

---

## Arquivos

- `manifest.json` — configuração da extensão (Manifest V3)
- `background.js` — busca os cards/categorias no Supabase
- `content.js` — painel + leitura da mensagem + motor de sugestão
- `panel.css` — estilo do painel
- `icon128.png` — ícone (logo Equilibrium)
