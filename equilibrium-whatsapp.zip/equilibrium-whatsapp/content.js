/* ============================================================
   Equilibrium · Assistente — content script (WhatsApp Web)
   - Injeta um painel lateral
   - Lê a última mensagem RECEBIDA da conversa aberta
   - Identifica a intenção e sugere as mensagens do painel
   - NÃO envia nada: a atendente copia e cola manualmente
   ============================================================ */
(function () {
  if (window.__equiAssistLoaded) return;
  window.__equiAssistLoaded = true;

  let CARDS = [];
  let CATS = [];
  let VARS = [];
  let CTX = {};
  let lastMsg = '';
  let aberto = true;

  const esc = s => (s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const norm = s => (s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const cat = id => CATS.find(c => c.id === id) || { id: id, nome: id || '—', cor: '#1868B0' };
  const codeOf = (t, ct) => { const p = (t || '').split('·'); const c = p.length > 1 ? p[0].trim() : ''; return (c && c.length <= 12) ? c : (ct ? ct.id : ''); };
  const shortOf = t => { const p = (t || '').split('·'); return (p.length > 1 ? p[1] : p[0] || '').trim(); };

  /* ---------- preenchimento dos campos [ ] ---------- */
  function preencher(txt) {
    return (txt || '').replace(/\[([^\]]+)\]/g, (m, tok) => {
      const k = tok.trim().toUpperCase();
      return (CTX[k] && String(CTX[k]).trim()) ? CTX[k] : m;
    });
  }
  function realcar(txt) {
    // preenche o que dá e destaca o que ainda ficou em branco
    return esc(preencher(txt)).replace(/\[([^\]]+)\]/g, '<mark class="equi-ph">[$1]</mark>');
  }
  function salvarCtx() { try { chrome.storage.local.set({ equiCtx: CTX }); } catch (e) {} }
  function restaurarCtx(cb) {
    try { chrome.storage.local.get('equiCtx', d => { CTX = (d && d.equiCtx) || {}; if (cb) cb(); }); }
    catch (e) { if (cb) cb(); }
  }

  /* ---------- motor de identificação (igual ao painel) ---------- */
  function ranquear(msg, limite) {
    const m = ' ' + norm(msg) + ' ';
    const scored = CARDS.map(c => {
      const toks = [...new Set(norm((c.palavras_chave || '') + ' ' + (c.titulo || '')).split(/[^a-z0-9]+/).filter(t => t.length >= 3))];
      let s = 0;
      toks.forEach(t => { if (m.indexOf(t) >= 0) s += (t.length >= 5 ? 1.4 : 1); });
      return { card: c, score: s };
    }).filter(x => x.score > 0).sort((a, b) => b.score - a.score);
    return scored.slice(0, limite || 6);
  }
  function nivel(score) {
    if (score >= 3) return { t: 'alta', bg: '#1E8A5A' };
    if (score >= 1.4) return { t: 'média', bg: '#b8743a' };
    return { t: 'baixa', bg: '#b1452f' };
  }

  /* ---------- painel ---------- */
  function montarPainel() {
    const wrap = document.createElement('div');
    wrap.id = 'equi-assist';
    wrap.innerHTML = `
      <div class="equi-top">
        <div class="equi-logo">E</div>
        <div class="equi-ttl"><b>Assistente Equilibrium</b><span id="equi-status">carregando cards…</span></div>
        <button id="equi-refresh" title="Recarregar cards">&#x21bb;</button>
        <button id="equi-hide" title="Recolher">&#x2715;</button>
      </div>
      <div class="equi-dados">
        <button class="equi-dados-h" id="equi-dados-h">Dados do atendimento — preencha para os cards saírem prontos <span id="equi-dados-caret">&#x25be;</span></button>
        <div class="equi-dados-body" id="equi-dados-body"></div>
      </div>
      <div class="equi-detect">
        <div class="equi-lab">Última mensagem recebida</div>
        <div id="equi-msg" class="equi-msg">—</div>
        <div class="equi-manual">
          <input id="equi-input" placeholder="ou cole/escreva uma mensagem para analisar…" />
          <button id="equi-go" title="Analisar">Analisar</button>
        </div>
      </div>
      <div id="equi-sugs" class="equi-sugs"></div>
      <div class="equi-foot">Sugere — quem envia é você. Cards ao vivo do painel.</div>
      <div class="equi-grip" id="equi-grip" title="Arraste para redimensionar"></div>`;
    document.body.appendChild(wrap);

    const fab = document.createElement('button');
    fab.id = 'equi-fab';
    fab.title = 'Assistente Equilibrium';
    fab.textContent = 'E';
    fab.style.display = 'none';
    document.body.appendChild(fab);

    document.getElementById('equi-hide').onclick = () => toggle(false);
    document.getElementById('equi-refresh').onclick = carregar;
    document.getElementById('equi-go').onclick = analisarManual;
    document.getElementById('equi-input').addEventListener('keydown', e => { if (e.key === 'Enter') analisarManual(); });
  }

  function toggle(v) {
    aberto = v;
    document.getElementById('equi-assist').style.display = v ? 'flex' : 'none';
    document.getElementById('equi-fab').style.display = v ? 'none' : 'flex';
  }

  function setStatus(t) { const s = document.getElementById('equi-status'); if (s) s.textContent = t; }

  /* ---------- arrastar / redimensionar / lembrar posição ---------- */
  function salvarGeom() {
    const p = document.getElementById('equi-assist'); if (!p) return;
    const r = p.getBoundingClientRect();
    try { chrome.storage.local.set({ equiGeom: { left: r.left, top: r.top, width: r.width, height: r.height } }); } catch (e) {}
  }
  function restaurarGeom() {
    try {
      chrome.storage.local.get('equiGeom', d => {
        const g = d && d.equiGeom; if (!g) return;
        const p = document.getElementById('equi-assist'); if (!p) return;
        p.style.right = 'auto';
        p.style.left = Math.max(4, Math.min(g.left, window.innerWidth - 80)) + 'px';
        p.style.top = Math.max(4, Math.min(g.top, window.innerHeight - 40)) + 'px';
        if (g.width) p.style.width = g.width + 'px';
        if (g.height) { p.style.maxHeight = 'none'; p.style.height = g.height + 'px'; }
      });
    } catch (e) {}
  }
  function habilitarArrastar() {
    const p = document.getElementById('equi-assist');
    const top = p.querySelector('.equi-top');
    let sx, sy, ox, oy, drag = false;
    top.addEventListener('mousedown', e => {
      if (e.target.closest('button')) return;   // clicar nos botões não arrasta
      drag = true;
      const r = p.getBoundingClientRect();
      p.style.right = 'auto'; p.style.left = r.left + 'px'; p.style.top = r.top + 'px';
      sx = e.clientX; sy = e.clientY; ox = r.left; oy = r.top;
      document.body.style.userSelect = 'none'; e.preventDefault();
    });
    window.addEventListener('mousemove', e => {
      if (!drag) return;
      let nx = ox + (e.clientX - sx), ny = oy + (e.clientY - sy);
      nx = Math.max(4, Math.min(nx, window.innerWidth - 80));
      ny = Math.max(4, Math.min(ny, window.innerHeight - 40));
      p.style.left = nx + 'px'; p.style.top = ny + 'px';
    });
    window.addEventListener('mouseup', () => { if (drag) { drag = false; document.body.style.userSelect = ''; salvarGeom(); } });
  }
  function habilitarRedimensionar() {
    const p = document.getElementById('equi-assist');
    const grip = document.getElementById('equi-grip');
    let sx, sy, sw, sh, rz = false;
    grip.addEventListener('mousedown', e => {
      rz = true;
      const r = p.getBoundingClientRect();
      sx = e.clientX; sy = e.clientY; sw = r.width; sh = r.height;
      document.body.style.userSelect = 'none'; e.preventDefault(); e.stopPropagation();
    });
    window.addEventListener('mousemove', e => {
      if (!rz) return;
      let nw = sw + (e.clientX - sx), nh = sh + (e.clientY - sy);
      nw = Math.max(280, Math.min(nw, 760));
      nh = Math.max(260, Math.min(nh, window.innerHeight - 16));
      p.style.width = nw + 'px'; p.style.maxHeight = 'none'; p.style.height = nh + 'px';
    });
    window.addEventListener('mouseup', () => { if (rz) { rz = false; document.body.style.userSelect = ''; salvarGeom(); } });
  }

  /* ---------- arrastar a bolinha (FAB) ---------- */
  function salvarFab() {
    const f = document.getElementById('equi-fab'); if (!f) return;
    const r = f.getBoundingClientRect();
    try { chrome.storage.local.set({ equiFab: { left: r.left, top: r.top } }); } catch (e) {}
  }
  function restaurarFab() {
    try {
      chrome.storage.local.get('equiFab', d => {
        const g = d && d.equiFab; if (!g) return;
        const f = document.getElementById('equi-fab'); if (!f) return;
        f.style.right = 'auto'; f.style.bottom = 'auto';
        f.style.left = Math.max(4, Math.min(g.left, window.innerWidth - 58)) + 'px';
        f.style.top = Math.max(4, Math.min(g.top, window.innerHeight - 58)) + 'px';
      });
    } catch (e) {}
  }
  function habilitarArrastarBolinha() {
    const fab = document.getElementById('equi-fab');
    let sx, sy, ox, oy, down = false, moved = false;
    fab.addEventListener('mousedown', e => {
      down = true; moved = false;
      const r = fab.getBoundingClientRect();
      fab.style.right = 'auto'; fab.style.bottom = 'auto';
      fab.style.left = r.left + 'px'; fab.style.top = r.top + 'px';
      sx = e.clientX; sy = e.clientY; ox = r.left; oy = r.top;
      e.preventDefault();
    });
    window.addEventListener('mousemove', e => {
      if (!down) return;
      const dx = e.clientX - sx, dy = e.clientY - sy;
      if (Math.abs(dx) > 4 || Math.abs(dy) > 4) moved = true;
      let nx = ox + dx, ny = oy + dy;
      nx = Math.max(4, Math.min(nx, window.innerWidth - 58));
      ny = Math.max(4, Math.min(ny, window.innerHeight - 58));
      fab.style.left = nx + 'px'; fab.style.top = ny + 'px';
    });
    window.addEventListener('mouseup', () => { if (down) { down = false; if (moved) salvarFab(); } });
    // clique só abre se NÃO tiver arrastado
    fab.addEventListener('click', () => { if (!moved) toggle(true); });
  }

  /* ---------- barra "Dados do atendimento" ---------- */
  function renderDados() {
    const body = document.getElementById('equi-dados-body'); if (!body) return;
    if (!VARS.length) { body.innerHTML = '<div class="equi-dados-vazio">Sem campos configurados no painel.</div>'; return; }
    body.innerHTML = VARS.map(v => `
      <label class="equi-f"><span>${esc(v.rotulo || v.chave)}</span>
        <input data-k="${esc(v.chave)}" value="${esc(CTX[v.chave] || '')}" placeholder="${esc(v.rotulo || v.chave)}"></label>`).join('')
      + '<button class="equi-dados-clear" id="equi-dados-clear">Limpar dados</button>';
    body.querySelectorAll('input[data-k]').forEach(inp => {
      inp.addEventListener('input', () => { CTX[inp.dataset.k] = inp.value; salvarCtx(); if (lastMsg) renderSugestoes(lastMsg); });
    });
    const clr = document.getElementById('equi-dados-clear');
    if (clr) clr.onclick = () => { CTX = {}; salvarCtx(); renderDados(); if (lastMsg) renderSugestoes(lastMsg); };
  }
  function habilitarDados() {
    const h = document.getElementById('equi-dados-h');
    const body = document.getElementById('equi-dados-body');
    if (!h || !body) return;
    h.onclick = () => {
      body.classList.toggle('collapsed');
      const c = document.getElementById('equi-dados-caret');
      if (c) c.innerHTML = body.classList.contains('collapsed') ? '&#x25b8;' : '&#x25be;';
    };
  }

  /* ---------- carregar dados ---------- */
  function carregar() {
    setStatus('carregando cards…');
    chrome.runtime.sendMessage({ type: 'getData' }, resp => {
      if (!resp || !resp.ok) { setStatus('erro ao carregar — clique em ↻'); return; }
      CARDS = resp.data.cards || [];
      CATS = resp.data.cats || [];
      VARS = resp.data.vars || [];
      setStatus(CARDS.length + ' cards · ' + CATS.length + ' categorias');
      renderDados();
      if (lastMsg) renderSugestoes(lastMsg);
    });
  }

  /* ---------- render ---------- */
  function renderSugestoes(msg) {
    const box = document.getElementById('equi-sugs');
    document.getElementById('equi-msg').textContent = msg || '—';
    const res = ranquear(msg, 6);
    if (!res.length) {
      box.innerHTML = `<div class="equi-vazio">Não identifiquei o fluxo por essas palavras.<br>Tente palavras como “valores”, “agendar”, “como funciona”.</div>`;
      return;
    }
    box.innerHTML = res.map((r, i) => {
      const c = r.card, ct = cat(c.categoria_id), nv = nivel(r.score);
      return `<div class="equi-card ${i === 0 ? 'top' : ''}">
        <div class="equi-ch">
          <span class="equi-tag" style="background:${ct.cor}">${esc(codeOf(c.titulo, ct))}</span>
          <span class="equi-nome">${esc(shortOf(c.titulo))}</span>
          <span class="equi-niv" style="background:${nv.bg}">${nv.t}</span>
        </div>
        <div class="equi-txt">${realcar(c.texto || '')}</div>
        <div class="equi-acts">
          <button class="equi-copy" data-id="${c.id}">Copiar mensagem</button>
          <span class="equi-cat">${esc(ct.nome)}</span>
        </div>
      </div>`;
    }).join('');
    box.querySelectorAll('.equi-copy').forEach(b => {
      b.onclick = async () => {
        const c = CARDS.find(x => x.id === b.dataset.id); if (!c) return;
        try { await navigator.clipboard.writeText(preencher(c.texto || '')); } catch (e) {}
        const old = b.textContent; b.textContent = 'Copiado ✓'; b.classList.add('done');
        setTimeout(() => { b.textContent = old; b.classList.remove('done'); }, 1300);
      };
    });
  }

  function analisarManual() {
    const inp = document.getElementById('equi-input');
    const v = (inp.value || '').trim();
    if (!v) return;
    lastMsg = v;
    if (!aberto) toggle(true);
    renderSugestoes(v);
  }

  /* ---------- leitura do WhatsApp Web ---------- */
  function ultimaRecebida() {
    // seletores do WhatsApp Web (podem mudar com atualizações)
    const ins = document.querySelectorAll('#main div.message-in');
    for (let i = ins.length - 1; i >= 0; i--) {
      const sp = ins[i].querySelector('span.selectable-text');
      const txt = sp ? sp.innerText.trim() : '';
      if (txt) return txt;
    }
    return '';
  }

  let deb = null;
  function checar() {
    clearTimeout(deb);
    deb = setTimeout(() => {
      const t = ultimaRecebida();
      if (t && t !== lastMsg) {
        lastMsg = t;
        if (!aberto) toggle(true);
        renderSugestoes(t);
      }
    }, 350);
  }

  function observar() {
    const alvo = document.querySelector('#main') || document.body;
    const mo = new MutationObserver(checar);
    mo.observe(alvo, { childList: true, subtree: true });
    // reanexa quando troca de conversa (#main é recriado)
    setInterval(() => {
      const main = document.querySelector('#main');
      if (main && !main.__equiObs) { main.__equiObs = true; new MutationObserver(checar).observe(main, { childList: true, subtree: true }); checar(); }
    }, 2500);
  }

  /* ---------- start ---------- */
  function start() {
    montarPainel();
    habilitarArrastar();
    habilitarRedimensionar();
    habilitarArrastarBolinha();
    habilitarDados();
    restaurarGeom();
    restaurarFab();
    restaurarCtx(carregar);
    observar();
  }
  // espera o WhatsApp carregar
  const wait = setInterval(() => {
    if (document.body) { clearInterval(wait); start(); }
  }, 500);
})();
