/* ============================================================
   Equilibrium · Assistente — service worker
   Busca os cards e categorias direto do Supabase do painel.
   Roda no background para não esbarrar em CORS.
   ============================================================ */
const SB_URL  = 'https://bhrzxpudwstofqasbjnv.supabase.co';
const ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJocnp4cHVkd3N0b2ZxYXNiam52Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODI0MTA5NDUsImV4cCI6MjA5Nzk4Njk0NX0.3X3pu6MIFG4Oa17UdWAYubFXt-hPGW7c2bKY2HXO8Zg';

async function getData(){
  const h = { apikey: ANON_KEY, Authorization: 'Bearer ' + ANON_KEY };
  const [cards, cats, vars] = await Promise.all([
    fetch(`${SB_URL}/rest/v1/cards?select=id,categoria_id,titulo,texto,palavras_chave,origem&order=atualizado_em.desc`, { headers: h }).then(r => r.json()),
    fetch(`${SB_URL}/rest/v1/categorias?select=id,nome,cor,ordem&order=ordem`, { headers: h }).then(r => r.json()),
    fetch(`${SB_URL}/rest/v1/variaveis?select=chave,rotulo,ordem&order=ordem`, { headers: h }).then(r => r.json())
  ]);
  return {
    cards: Array.isArray(cards) ? cards : [],
    cats: Array.isArray(cats) ? cats : [],
    vars: Array.isArray(vars) ? vars : []
  };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'getData') {
    getData()
      .then(data => sendResponse({ ok: true, data }))
      .catch(err => sendResponse({ ok: false, error: String(err) }));
    return true;
  }
});
